﻿namespace SqlEditor.DatabaseExplorer
{
    public class EncryptionInfo
    {
        public static string EncryptionKey { get { return "kjdhfkjda78678";  } }
    }
}
