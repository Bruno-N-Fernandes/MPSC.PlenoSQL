﻿namespace SqlEditor.DatabaseExplorer
{
    //public class Column
    //{
    //    public string ParentName { get; set; }
    //    public string Name { get; set; }
    //    public string DataType { get; set; }
    //    public int DataLength { get; set; }
    //    public int DataPrecision { get; set; }
    //    public int DataScale { get; set; }
    //    public bool Nullable { get; set; }

    //    public Column(string parentName)
    //    {
    //        ParentName = parentName;
    //    }
    //}
}