﻿namespace SqlEditor.Databases
{
    public class PackageProcedure : DatabaseObject
    {
        public PackageProcedure(string name, DatabaseObject parent)
            : base(name, parent)
        {
        }

        public PackageProcedure()
        {
        }

        public override void Clear()
        {
            
        }
    }
}