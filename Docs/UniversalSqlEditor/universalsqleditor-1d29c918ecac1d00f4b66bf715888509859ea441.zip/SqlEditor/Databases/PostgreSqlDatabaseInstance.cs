﻿namespace SqlEditor.Databases
{
    public class PostgreSqlDatabaseInstance : DatabaseInstance
    {
        
    }
}