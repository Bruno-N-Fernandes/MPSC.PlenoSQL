namespace SqlEditor.Databases
{
    public enum DatabaseServerType
    {
        SQLServer = 0,
        ORACLE = 1,
        DB2 = 2,
        MySQL = 3,
        SQLite = 4,
        SQLServerCompact = 5,
        MicrosoftAccess2003 = 6,
        MicrosoftAccess2007 = 7
    }
}