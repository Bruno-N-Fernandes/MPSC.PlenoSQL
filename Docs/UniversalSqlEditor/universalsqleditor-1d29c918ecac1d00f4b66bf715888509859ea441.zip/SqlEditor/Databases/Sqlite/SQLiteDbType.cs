namespace SqlEditor.Databases.Sqlite
{
    public enum SqliteDbType
    {
        Integer = 12,
        Varchar = 16,
        Real = 15,
        Blob = 1
    }
}