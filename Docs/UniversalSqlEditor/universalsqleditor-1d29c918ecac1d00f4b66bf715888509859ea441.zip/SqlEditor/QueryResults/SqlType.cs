namespace SqlEditor.QueryResults
{
    public enum SqlType
    {
        Query = 0,
        Dml = 1,
        Ddl = 2
    }
}