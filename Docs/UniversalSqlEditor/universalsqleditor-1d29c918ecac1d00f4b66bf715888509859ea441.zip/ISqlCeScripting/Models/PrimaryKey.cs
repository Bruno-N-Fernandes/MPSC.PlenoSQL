﻿
namespace ErikEJ.SqlCeScripting
{
    public struct PrimaryKey
    {
        public string KeyName { get; set; }
        public string ColumnName { get; set; }
        public string TableName { get; set; }
    }

}
