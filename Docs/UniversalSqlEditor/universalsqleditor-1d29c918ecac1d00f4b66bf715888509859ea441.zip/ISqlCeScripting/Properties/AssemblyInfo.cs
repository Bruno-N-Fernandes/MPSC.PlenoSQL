﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
[assembly: AssemblyTitle("SQL Compact Scripting Utility")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("http://erikej.blogspot.com")]
[assembly: AssemblyProduct("SQL Compact Scripting Utility")]
[assembly: AssemblyCopyright("Copyright © Bembeng Arifin/Erik Ejlskov Jensen 2011")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly:ComVisible(false)]
[assembly: AssemblyVersion("3.5.2.15")]
[assembly: AssemblyFileVersion("3.5.2.41")]
[assembly: AssemblyInformationalVersion("3.5.2.41")]