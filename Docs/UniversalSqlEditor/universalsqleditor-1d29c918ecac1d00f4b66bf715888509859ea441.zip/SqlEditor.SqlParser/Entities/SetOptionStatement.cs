namespace SqlEditor.SqlParser.Entities
{
    public class SetOptionStatement : SetStatement
    {
        public string Option { get; set; }
    }
}