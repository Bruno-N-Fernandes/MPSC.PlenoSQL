namespace SqlEditor.SqlParser.Entities
{
    public class SetDeadlockPriorityStatement : SetStatement
    {
    }
}