namespace SqlEditor.SqlParser.Entities
{
    public class SetVariableStatement : SetStatement
    {
        public string Variable { get; set; }
    }
}