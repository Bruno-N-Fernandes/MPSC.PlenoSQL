﻿namespace SqlEditor.SqlParser.Entities
{
    public class TableHint
    {
        public string Hint { get; set; }
    }
}