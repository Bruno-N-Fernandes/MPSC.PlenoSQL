namespace SqlEditor.SqlParser.Entities
{
    public class SetDateFirstStatement : SetStatement
    {
    }

    public class SetDateFormatStatement : SetStatement
    {
    }
}