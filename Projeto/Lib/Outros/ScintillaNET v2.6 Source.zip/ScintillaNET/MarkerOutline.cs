﻿#region Using Directives

using System;

#endregion Using Directives


namespace ScintillaNET
{
    public enum MarkerOutline
    {
        FolderEnd = 25,
        FolderOpenMid = 26,
        FolderMidTail = 27,
        FolderTail = 28,
        FolderSub = 29,
        Folder = 30,
        FolderOpen = 31,
    }
}
