﻿#region Using Directives

using System;

#endregion Using Directives


namespace ScintillaNET
{
    internal class StyleRunReader
    {
        // Reserved for future use
    }
}
