﻿#region Using Directives

using System;

#endregion Using Directives

namespace ScintillaNET
{
    public enum FoldMarkerScheme
    {
        PlusMinus,
        BoxPlusMinus,
        CirclePlusMinus,
        Arrow,
        Custom
    }
}
