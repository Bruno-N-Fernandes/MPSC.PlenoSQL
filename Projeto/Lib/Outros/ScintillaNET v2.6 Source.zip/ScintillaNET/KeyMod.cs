﻿#region Using Directives

using System;

#endregion Using Directives


namespace ScintillaNET
{
    public enum KeyMod
    {
        Norm = 0,
        Shift = 1,
        Ctrl = 2,
        Alt = 4,
    }
}
