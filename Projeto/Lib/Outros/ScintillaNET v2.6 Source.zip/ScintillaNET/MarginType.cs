﻿#region Using Directives

using System;

#endregion Using Directives


namespace ScintillaNET
{
    public enum MarginType
    {
        Symbol = 0,
        Number = 1,
        Back = 2,
        Fore = 3,
    }
}
