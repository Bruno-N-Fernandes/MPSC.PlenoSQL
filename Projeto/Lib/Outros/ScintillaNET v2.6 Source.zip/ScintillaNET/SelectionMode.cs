﻿#region Using Directives

using System;

#endregion Using Directives


namespace ScintillaNET
{
    public enum SelectionMode
    {
        Stream = 0,
        Rectangle = 1,
        Lines = 2,
    }
}
