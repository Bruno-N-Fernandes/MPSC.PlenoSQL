﻿#region Using Directives

using System;

#endregion Using Directives


namespace ScintillaNET
{
    public enum CopyFormat
    {
        Text,
        Rtf,
        Html
    }
}
