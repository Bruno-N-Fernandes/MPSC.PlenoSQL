﻿#region Using Directives

using System;

#endregion Using Directives


namespace ScintillaNET
{
    public enum CursorShape
    {
        Normal = -1,
        Wait = 4,
    }
}
