using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

#if !DEBUG
[assembly: AssemblyVersion("2.0.0.47")]
[assembly: AssemblyFileVersion("2.0.0.47")]

#endif