using System;
using System.Collections.Generic;
using System.Text;
using Fireball.Docking;

namespace DockingTest
{
    class MyDocument : DockableWindow
    {
        public MyDocument()
        {
            this.Text = "MyDocumentooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo";

        }
    }
}
