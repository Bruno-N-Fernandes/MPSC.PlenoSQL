using System;
using System.Collections.Generic;
using System.Text;

namespace Fireball.Drawing.Design
{
    public delegate void ColorChangedDelegate(object sender, ColorChangedEventArgs e);
}
